package analysis;

import weka.core.Instances;

public class Analysis {
	public void analyze(Instances data) {
    	int numAttributes = data.numAttributes();

        int numInstances = data.numInstances();

        System.out.println("\nAnalysis Before Cleaning");
        System.out.println("Number of attributes: " + numAttributes);
        System.out.println("Number of instances: " + numInstances);

        System.out.println("\nAttribute details:");
        for (int i = 0; i < data.numAttributes(); i++) {
            System.out.println("- " + data.attribute(i).name() + " (Type: " + data.attribute(i).type() + ")");
        }
        
        
        System.out.println("\nAnalysis after cleaning");
        for (int i = 0; i < data.numAttributes(); i++) {
            System.out.println("Attribute: " + data.attribute(i).name());
            System.out.println("Type: " + attributeTypeToString(data.attribute(i).type()));
            System.out.println("Missing: " + data.attributeStats(i).missingCount);
            System.out.println("Distinct values: " + data.attributeStats(i).distinctCount);
        }
    }

    private String attributeTypeToString(int type) {
        switch (type) {
            case weka.core.Attribute.NUMERIC:
                return "numeric";
            case weka.core.Attribute.NOMINAL:
                return "nominal";
            case weka.core.Attribute.STRING:
                return "string";
            case weka.core.Attribute.DATE:
                return "date";
            case weka.core.Attribute.RELATIONAL:
                return "relational";
            default:
                return "unknown";
        }
    }
}