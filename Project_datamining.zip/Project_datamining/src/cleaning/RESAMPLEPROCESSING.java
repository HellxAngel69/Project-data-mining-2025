package cleaning;
import weka.core.Instances;
import weka.core.AttributeStats;
import weka.filters.supervised.instance.Resample;
import weka.filters.Filter;

public class RESAMPLEPROCESSING {
	private Instances data;

    public RESAMPLEPROCESSING(Instances data) {
        this.data = data;
    }

    public void applyRESAMPLE(int percentage, int k) throws Exception {
            if (data.classIndex() == -1) {
                System.out.println("\nClass index not set. Automatically setting last attribute as class.");
                data.setClassIndex(data.numAttributes() - 1);
            }

            
            Resample resample = new Resample();
            resample.setBiasToUniformClass(k);
            resample.setNoReplacement(false);
            resample.setRandomSeed(1);
            resample.setInputFormat(data);

            
            Instances newData = Filter.useFilter(data, resample);
            

            System.out.println("\nAfter Resample Class Distribution");
            AttributeStats classStats = newData.attributeStats(newData.classIndex());
            int[] counts = classStats.nominalCounts;

            for (int i = 0; i < counts.length; i++) {
                System.out.println(newData.classAttribute().value(i) + ": " + counts[i]);
            }

            this.data = newData;
    }

    public Instances getData() {
        return this.data;
    }

}
