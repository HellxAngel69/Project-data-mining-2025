package cleaning;

import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.ReplaceMissingValues;
import weka.filters.unsupervised.instance.RemoveDuplicates;
import java.util.*;

public class HandleDirty {
    public Instances apply(Instances data) throws Exception {
		
		ReplaceMissingValues replaceMissing = new ReplaceMissingValues();
		replaceMissing.setInputFormat(data);
		Instances CleanedData = Filter.useFilter(data, replaceMissing);
		
		System.out.println("Missing values replaced.");
		
		
        RemoveDuplicates removeDuplicates = new RemoveDuplicates();
        removeDuplicates.setInputFormat(CleanedData);
        CleanedData = Filter.useFilter(CleanedData, removeDuplicates);

		System.out.println("\nDuplicates removed.");
		
		double threshold = 0.01; 
        int numAttrs = CleanedData.numAttributes();
        int numInstances = CleanedData.numInstances();

        for (int a = 0; a < numAttrs; a++) {

            if (!CleanedData.attribute(a).isNumeric()) continue;

            List<Double> vals = new ArrayList<>();

            for (int i = 0; i < numInstances; i++) {
                if (!CleanedData.instance(i).isMissing(a)) {
                    vals.add(CleanedData.instance(i).value(a));
                }
            }
            if (vals.size() == 0) continue;

            Collections.sort(vals);

            double median = vals.get(vals.size() / 2);
            double q1 = vals.get(vals.size() / 4);
            double q3 = vals.get(3 * vals.size() / 4);
            double iqr = q3 - q1;

            double lower = q1 - 1.5 * iqr;
            double upper = q3 + 1.5 * iqr;

            int outCount = 0;
            for (double v : vals) {
                if (v < lower || v > upper) outCount++;
            }

            double ratio = (double) outCount / vals.size();

            System.out.println("\nAttribute: " + CleanedData.attribute(a).name());
            System.out.println("Outliers: " + outCount + " (" + (ratio * 100) + "%)");

            if (ratio > threshold) {
                System.out.println("→ Applying median replacement...");
                for (int i = 0; i < numInstances; i++) {
                    double v = CleanedData.instance(i).value(a);
                    if (v < lower || v > upper) {
                        CleanedData.instance(i).setValue(a, median);
                    }
                }
            } else {               
            	System.out.println("→ Outliers <= 1%, keep original.");
            }
        }
        return CleanedData;
    }
}