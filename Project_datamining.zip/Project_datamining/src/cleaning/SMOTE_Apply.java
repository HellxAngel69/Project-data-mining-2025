package cleaning;


import weka.core.Instances;
import weka.core.AttributeStats;
import weka.filters.supervised.instance.SMOTE;
import weka.filters.Filter;

public class SMOTE_Apply {

    private Instances data;

    public SMOTE_Apply(Instances data) {
        this.data = data;
    }

    public void applySMOTE(int percentage) {
        try {
            if (data.classIndex() == -1) {
                System.out.println("\nClass index not set. Automatically setting last attribute as class.");
                data.setClassIndex(data.numAttributes() - 1);
            }

            
            SMOTE smote = new SMOTE();
            smote.setPercentage(percentage);
            smote.setInputFormat(data);


            Instances newData = Filter.useFilter(data, smote);

            System.out.println("\nAfter SMOTE Class Distribution");
            AttributeStats classStats = newData.attributeStats(newData.classIndex());
            int[] counts = classStats.nominalCounts;

            for (int i = 0; i < counts.length; i++) {
                System.out.println(newData.classAttribute().value(i) + ": " + counts[i]);
            }

            this.data = newData;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Instances getData() {
        return this.data;
    }
}