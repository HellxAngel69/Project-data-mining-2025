package project;

import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Discretize;
import weka.associations.Apriori;

public class SequenceMining {

	public static void runApriori(Instances data) throws Exception {

        System.out.println("\n");
        System.out.println("Sequence mining - Apriori");
        System.out.println("\n");

        data.setClassIndex(data.numAttributes() - 1);

        Discretize discretize = new Discretize(); 
        discretize.setBins(5);                   
        discretize.setInputFormat(data);

        Instances discData = Filter.useFilter(data, discretize);

        System.out.println("\nAfter Discretization");
        System.out.println(discData);

        Apriori apriori = new Apriori();

        apriori.setNumRules(50); 
        
        apriori.setMinMetric(0.8); 

        apriori.setLowerBoundMinSupport(0.05); 

        apriori.setClassIndex(discData.classIndex());


        apriori.buildAssociations(discData);

        System.out.println("\nApriori association rules");
        System.out.println(apriori.toString());
        
    }
}
