package project;

import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

public class Load_data {
    public Instances load(String filePath) throws Exception {
        DataSource source = new DataSource(filePath);
        Instances data = source.getDataSet();
        System.out.println("Loaded dataset: " + data.numInstances() + " instances, " + data.numAttributes() + " attributes.");
        return data;
    }
}
