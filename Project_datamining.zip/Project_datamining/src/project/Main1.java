package project;
import java.io.File;
import weka.core.Instances;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.trees.RandomForest;
import classification.Classification;


public class Main1 {

	public static void main(String[] args) throws Exception {
		if (args.length < 2) {
            System.out.println("Usage: java Main1 <inputFile> <outputFolder>");
            return;
        }

        String inputPath = args[0];
        String outputFolder = args[1];

        File f = new File(inputPath);
        if (!f.exists()) {
            System.out.println("Input file not found: " + inputPath);
            return;
        }
        
		Load_data loader = new Load_data();
	    Instances data = loader.load(f.getAbsolutePath());
	    
		Classification cls = new Classification(data); 
		NaiveBayes nb = cls.NaiveB(outputFolder);
		//NaiveBayes na = cls.NaiveB(outputFolder);
		//cls.validate(nb);
		//RandomForest fr = cls.RandomForest(outputFolder);
		//cls.crossvalidate(fr, 10);
		cls.crossvalidate(nb, 10);
		
	    long startTime = System.currentTimeMillis();
	    long endTime = System.currentTimeMillis();
	    System.out.println("Total Execution Time: " + (endTime - startTime) + "ms");
	}

}
