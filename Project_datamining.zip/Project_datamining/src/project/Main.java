package project;

import weka.core.Instances;
import java.io.File;
import cleaning.*;
import analysis.Analysis;

public class Main {
    public static void main(String[] args) throws Exception {

        if (args.length < 2) {
            System.out.println("Usage: java Main <inputData> <outputFolder>");
            return;
        }

        String inputPath = args[0];
        String outputFolder = args[1];

        Load_data loader = new Load_data();
        File file = new File(inputPath);

        if (!file.exists()) {
            System.out.println("File not found: " + inputPath);
            return;
        }

        Instances data = loader.load(file.getAbsolutePath());
        data.setClassIndex(data.numAttributes() - 1);

        Analysis analyzer = new Analysis();
        analyzer.analyze(data);

        HandleDirty cleaner = new HandleDirty();
        data = cleaner.apply(data);

        System.out.println("\nData cleaning and analysis completed successfully!");

        data = FeatureSelection.Feature_Selection(data);

        RESAMPLEPROCESSING resample = new RESAMPLEPROCESSING(data);
        resample.applyRESAMPLE(100, 1);
        data = resample.getData();

        NewData saver = new NewData();
        saver.save(data, outputFolder + "/After_Cleaning.arff");
    }
}
