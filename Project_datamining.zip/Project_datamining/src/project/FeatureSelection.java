package project;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.supervised.attribute.AttributeSelection;
import weka.attributeSelection.InfoGainAttributeEval;
import weka.attributeSelection.Ranker;
public class FeatureSelection {
	public static Instances Feature_Selection(Instances data) throws Exception {
	    System.out.println("\nApplying Feature Selection (Information Gain + Ranker)");

	    if (data.classIndex() == -1) {
	        data.setClassIndex(data.numAttributes() - 1);
	    }

	    AttributeSelection filter = new AttributeSelection();

	    InfoGainAttributeEval evaluator = new InfoGainAttributeEval();
	    evaluator.buildEvaluator(data);

	    System.out.println("\nInformation Gain Scores:");
	    for (int i = 0; i < data.numAttributes() - 1; i++) { 
	        System.out.println(data.attribute(i).name() + " : " + evaluator.evaluateAttribute(i));}
	    
	    Ranker search = new Ranker();
	    search.setNumToSelect(11); 

	    filter.setEvaluator(evaluator);
	    filter.setSearch(search);
	    filter.setInputFormat(data);

	    Instances selectedData = Filter.useFilter(data, filter);

	    System.out.println("\nSelected attributes:");
	    for (int i = 0; i < selectedData.numAttributes(); i++) {
	        System.out.println("- " + selectedData.attribute(i).name());
	    }

	    return selectedData;
		}
}
