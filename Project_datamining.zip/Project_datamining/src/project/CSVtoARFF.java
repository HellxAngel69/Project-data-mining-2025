package project;

import weka.core.Instances;
import weka.core.converters.ArffSaver;

import weka.core.converters.CSVLoader;
import java.io.File;

public class CSVtoARFF {
    public static void main(String[] args) throws Exception {
        
    	CSVLoader loader = new CSVLoader();
    	loader.setSource(new File("D:/Khoa/2025-2026/Data mining/project/heart_disease.csv"));
        Instances data = loader.getDataSet();
        
        ArffSaver saver = new ArffSaver();
        saver.setInstances(data);
        saver.setFile(new File("D:/Khoa/2025-2026/Data mining/project/heart_disease.arff"));
        saver.writeBatch();

    }
}
