package project;

import java.io.File;
import weka.core.Instances;


public class MainAppriori {
	public static void main(String[] args) throws Exception {
		if (args.length < 1) {
            System.out.println("Usage: java Main <inputFile>");
            return;
        }

        String inputPath = args[0];

        File f = new File(inputPath);
        if (!f.exists()) {
            System.out.println("Input file not found: " + inputPath);
            return;
        }
        
		Load_data loader = new Load_data();
	    Instances data = loader.load(f.getAbsolutePath());

	        System.out.println("\nRUNNING APRIORI (SEQUENCE MINING)");
	        SequenceMining.runApriori(data);
	    }

}
