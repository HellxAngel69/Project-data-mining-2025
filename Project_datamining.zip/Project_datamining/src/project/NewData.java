package project;


import java.io.File;
import weka.core.Instances;
import weka.core.converters.ArffSaver;

public class NewData {
    public void save(Instances data, String outputPath) throws Exception {
        ArffSaver saver = new ArffSaver();
        saver.setInstances(data);
        saver.setFile(new File(outputPath));
        saver.writeBatch();
        System.out.println("Output path for new data: " + outputPath);
    }
}
