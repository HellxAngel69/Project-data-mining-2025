package classification;

import java.util.Random;
import weka.core.Instances;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.trees.RandomForest;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.core.SerializationHelper;

public class Classification {
	Instances data;
	Instances train;
	Instances test;
	public Classification(Instances data) {

	    this.data  = new Instances(data);

	    if (this.data.classIndex() == -1) {
	        this.data.setClassIndex(this.data.numAttributes() - 1);

	    }

	    Instances temp = new Instances(this.data);
	    temp.randomize(new Random(1));

	    int trainSize = (int) Math.round(temp.numInstances() * 0.7);
	    int testSize  = temp.numInstances() - trainSize;

	    this.train = new Instances(temp, 0, trainSize);
	    this.test  = new Instances(temp, trainSize, testSize);

	    this.train.setClassIndex(this.train.numAttributes() - 1);
	    this.test.setClassIndex(this.test.numAttributes() - 1);
	}

    public NaiveBayes NaiveB(String outputFolder) throws Exception {
        NaiveBayes nb = new NaiveBayes();
        nb.buildClassifier(this.train);
        SerializationHelper.write(outputFolder + "/NAIVEBAYES.model", nb);
        System.out.println("NaiveBayes model saved to: " + outputFolder + "/NAIVEBAYES.model");
        return nb;
    }
    
    public RandomForest RandomForest(String outputFolder) throws Exception {
		RandomForest rf = new RandomForest();
		rf.setNumIterations(100);
		rf.setSeed(1);		
        rf.buildClassifier(this.train);
                
        SerializationHelper.write(outputFolder + "/RANDOMFOREST.model", rf);
        System.out.println("RandomForest model saved to: " + outputFolder + "/RANDOMFOREST.model");
        return rf;
	}
    public void validate(Classifier c ) throws Exception  {
    	 Evaluation eval = new Evaluation(this.train);
         eval.evaluateModel(c, this.test);

         System.out.println("Train/Test split applied (70/30)");
         System.out.println("Train size: " + this.train.numInstances());
         System.out.println("Test size:  " + this.test.numInstances());
         

         System.out.println(c.toString());
         System.out.println(eval.toSummaryString("\nResults\n", false));
         System.out.println(eval.toMatrixString("Overall Confusion Matrix\n"));
    	
    }
    public void crossvalidate(Classifier c, int k) throws Exception{
    	Evaluation eval = new Evaluation(this.train);
    	if (k > 1 && k < 100) {
            eval.crossValidateModel(c, data, k, new Random(1)); }
    	else {
    		  System.out.println("folds have to be in range from 2-99");
    	}
    	  System.out.println(c.toString());
          System.out.println(eval.toSummaryString("\nResults\n", false));
          System.out.println(eval.toMatrixString("Overall Confusion Matrix\n"));
     	
    }
    	
    
}